function to_cutaway() {
    var location1 = window.location.hostname;
    var new_url = location1 + '/cutaway';
    // var new_url = 'http://127.0.0.1:8000/cutaway';
    window.location.pathname = '/cutaway';
}